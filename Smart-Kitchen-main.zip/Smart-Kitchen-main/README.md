Hacka-Nu-thon 6.0 Nirma University
